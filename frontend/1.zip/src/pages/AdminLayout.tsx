import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { clearAccessToken } from '../api/client';
import { Logo } from '../components/brand/Logo';
import { ThemeToggle } from '../components/ui/ThemeToggle';
import styles from './AdminLayout.module.css';

const navItems = [
  { to: '/admin', end: true, icon: '◈', label: 'Огляд' },
  {
    to: '/admin/events',
    end: false,
    icon: '◎',
    label: 'Події',
    match: (path: string) =>
      path === '/admin/events' ||
      (path.startsWith('/admin/events/') && path !== '/admin/events/new'),
  },
  {
    to: '/admin/events/new',
    end: true,
    icon: '＋',
    label: 'Нова подія',
    match: (path: string) => path === '/admin/events/new',
  },
] as const;

export function AdminLayout() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const handleLogout = () => {
    clearAccessToken();
    navigate('/admin/login');
  };

  return (
    <div className={styles.shell}>
      <aside className={styles.sidebar}>
        <NavLink to="/admin" className={styles.brand}>
          <Logo size={40} showText={false} />
          <span className={styles.brandText}>
            <span className={styles.brandName}>Спортудей</span>
            <span className={styles.brandRole}>Керування</span>
          </span>
        </NavLink>

        <nav className={styles.nav}>
          {navItems.map((item) => {
            const active =
              'match' in item ? item.match(pathname) : pathname === item.to;
            return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={`${styles.navLink} ${active ? styles.navLinkActive : ''}`}
            >
              <span className={styles.navIcon}>{item.icon}</span>
              {item.label}
            </NavLink>
            );
          })}
        </nav>

        <div className={styles.sidebarFoot}>
          <div className={styles.sidebarActions}>
            <ThemeToggle />
            <button type="button" onClick={handleLogout} className={styles.logoutBtn}>
              Вийти
            </button>
          </div>
        </div>
      </aside>

      <div className={styles.main}>
        <div className={styles.mainInner}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
