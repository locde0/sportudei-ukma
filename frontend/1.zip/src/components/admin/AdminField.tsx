import type { InputHTMLAttributes, TextareaHTMLAttributes, ReactNode } from 'react';
import styles from './AdminField.module.css';

interface BaseProps {
  label: string;
  hint?: string;
  required?: boolean;
  footer?: ReactNode;
}

type InputFieldProps = BaseProps &
  InputHTMLAttributes<HTMLInputElement> & { as?: 'input' };

type TextareaFieldProps = BaseProps &
  TextareaHTMLAttributes<HTMLTextAreaElement> & { as: 'textarea' };

export function AdminField(props: InputFieldProps | TextareaFieldProps) {
  const { label, hint, required, footer, as = 'input', ...rest } = props;
  const id = rest.id ?? rest.name;

  return (
    <div className={styles.field}>
      <label className={styles.label} htmlFor={id}>
        {label}
        {required && <span className={styles.required}>*</span>}
      </label>

      {as === 'textarea' ? (
        <textarea
          className={styles.textarea}
          id={id}
          {...(rest as TextareaHTMLAttributes<HTMLTextAreaElement>)}
        />
      ) : (
        <input
          className={styles.input}
          id={id}
          {...(rest as InputHTMLAttributes<HTMLInputElement>)}
        />
      )}

      {(hint || footer) && (
        <div className={styles.footer}>
          {hint && <span className={styles.hint}>{hint}</span>}
          {footer}
        </div>
      )}
    </div>
  );
}
