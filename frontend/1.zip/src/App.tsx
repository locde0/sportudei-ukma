import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { PublicLayout } from './components/public/PublicLayout';
import { ProtectedRoute } from './components/ProtectedRoute';
import { HomePage } from './pages/public/HomePage';
import { EventsCatalog } from './pages/public/EventsCatalog';
import { EventDetailPage } from './pages/public/EventDetailPage';
import { Login } from './pages/admin/Login';
import { VerifyOTP } from './pages/admin/VerifyOTP';
import { AdminLayout } from './pages/AdminLayout';
import { Dashboard } from './pages/admin/Dashboard';
import { AdminEvents } from './pages/admin/AdminEvents';
import { EventForm } from './pages/admin/EventForm';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public website */}
        <Route element={<PublicLayout />}>
          <Route index element={<HomePage />} />
          <Route path="events" element={<EventsCatalog />} />
          <Route path="events/:id" element={<EventDetailPage />} />
        </Route>

        {/* Admin auth (no layout) */}
        <Route path="/admin/login" element={<Login />} />
        <Route path="/admin/verify" element={<VerifyOTP />} />

        {/* Admin panel (protected) */}
        <Route element={<ProtectedRoute />}>
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="events" element={<AdminEvents />} />
            <Route path="events/new" element={<EventForm />} />
            <Route path="events/:id" element={<EventForm />} />
          </Route>
        </Route>

        {/* Legacy redirects */}
        <Route path="/login" element={<Navigate to="/admin/login" replace />} />
        <Route path="/verify" element={<Navigate to="/admin/verify" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
