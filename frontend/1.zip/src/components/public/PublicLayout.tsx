import { useEffect } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Logo } from '../brand/Logo';
import { ThemeToggle } from '../ui/ThemeToggle';
import styles from './PublicLayout.module.css';

export function PublicLayout() {
  useEffect(() => {
    document.documentElement.classList.add('public-no-scrollbar');
    return () => document.documentElement.classList.remove('public-no-scrollbar');
  }, []);

  return (
    <div className={styles.layout}>
      <header className={styles.header}>
        <div className={styles.headerInner}>
          <Logo size={42} />

          <div className={styles.headerRight}>
            <nav className={styles.nav}>
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                }
              >
                Головна
              </NavLink>
              <NavLink
                to="/events"
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                }
              >
                Події
              </NavLink>
            </nav>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className={styles.main}>
        <Outlet />
      </main>

      <footer className={styles.footer}>
        <div className={styles.footerInner}>
          <div className={styles.footerBrandRow}>
            <Logo size={36} showText={false} to="/" />
            <div className={styles.footerText}>
              <span className={styles.footerBrand}>Спортудей</span>
              <span className={styles.footerMotto}>Спорт завжди!</span>
            </div>
          </div>
          <span className={styles.footerCopy}>
            © {new Date().getFullYear()} Студентська організація НаУКМА
          </span>
        </div>
      </footer>
    </div>
  );
}
