import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { LinkButton } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { fetchAdminEvents } from '../../api/events';
import type { EventListItem } from '../../types/event';
import { formatEventDate } from '../../utils/date';
import { resolveImageUrl } from '../../utils/imageUrl';
import styles from './Dashboard.module.css';

function pickUpcoming(events: EventListItem[], limit = 5): EventListItem[] {
  const now = Date.now();
  const upcoming = events
    .filter((e) => new Date(e.event_date).getTime() >= now)
    .sort((a, b) => new Date(a.event_date).getTime() - new Date(b.event_date).getTime());

  if (upcoming.length >= limit) return upcoming.slice(0, limit);

  const rest = events
    .filter((e) => new Date(e.event_date).getTime() < now)
    .sort((a, b) => new Date(b.event_date).getTime() - new Date(a.event_date).getTime());

  return [...upcoming, ...rest].slice(0, limit);
}

export function Dashboard() {
  const [events, setEvents] = useState<EventListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdminEvents()
      .then(setEvents)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const published = events.filter((e) => e.is_published).length;
  const upcoming = useMemo(() => pickUpcoming(events), [events]);

  return (
    <div>
      <section className={styles.welcome}>
        <h1 className={styles.welcomeTitle}>Вітаємо в кабінеті Спортудей</h1>
        <p className={styles.welcomeText}>
          Тут ви керуєте подіями організації — від чернетки до публікації на сайті.
        </p>
        <div className={styles.welcomeActions}>
          <LinkButton to="/admin/events/new">Створити подію</LinkButton>
          <LinkButton to="/admin/events" variant="secondary">
            Переглянути каталог
          </LinkButton>
        </div>
      </section>

      <div className={styles.stats}>
        <div className={styles.stat}>
          <p className={styles.statLabel}>Усього</p>
          <p className={styles.statValue}>{events.length}</p>
        </div>
        <div className={styles.stat}>
          <p className={styles.statLabel}>Опубліковано</p>
          <p className={styles.statValue}>{published}</p>
        </div>
        <div className={styles.stat}>
          <p className={styles.statLabel}>Чернетки</p>
          <p className={styles.statValue}>{events.length - published}</p>
        </div>
      </div>

      <section className={styles.eventsSection}>
        <div className={styles.eventsHead}>
          <div>
            <h2 className={styles.eventsTitle}>Найближчі події</h2>
            <p className={styles.eventsSubtitle}>
              {loading
                ? 'Завантаження…'
                : upcoming.length > 0
                  ? `${upcoming.length} з ${events.length} подій`
                  : 'Створіть першу подію в каталозі'}
            </p>
          </div>
          <Link to="/admin/events" className={styles.eventsLink}>
            Усі події →
          </Link>
        </div>

        {loading && (
          <div className={styles.eventsLoading}>
            {[1, 2, 3].map((i) => (
              <div key={i} className={styles.skeleton} aria-hidden />
            ))}
          </div>
        )}

        {!loading && upcoming.length === 0 && (
          <div className={styles.eventsEmpty}>
            <span className={styles.eventsEmptyIcon}>◎</span>
            <p className={styles.eventsEmptyTitle}>Подій ще немає</p>
            <p className={styles.eventsEmptyText}>
              Додайте марафон, турнір або лекцію — вона зʼявиться тут і на сайті.
            </p>
            <LinkButton to="/admin/events/new">Створити подію</LinkButton>
          </div>
        )}

        {!loading && upcoming.length > 0 && (
          <div className={styles.eventsList}>
            {upcoming.map((event) => {
              const isPast = new Date(event.event_date).getTime() < Date.now();

              return (
                <Link
                  key={event.id}
                  to={`/admin/events/${event.id}`}
                  className={styles.eventCard}
                >
                  <div className={styles.eventThumbWrap}>
                    {event.main_photo_url ? (
                      <img
                        src={resolveImageUrl(event.main_photo_url)}
                        alt=""
                        className={styles.eventThumb}
                      />
                    ) : (
                      <div className={styles.eventThumbEmpty}>◎</div>
                    )}
                  </div>

                  <div className={styles.eventBody}>
                    <div className={styles.eventMeta}>
                      <span className={styles.eventId}>#{event.id}</span>
                      <Badge published={event.is_published} />
                      {isPast && <span className={styles.eventPast}>Минула</span>}
                    </div>
                    <h3 className={styles.eventTitle}>{event.title}</h3>
                    <div className={styles.eventDetails}>
                      <span className={styles.eventDetail}>
                        <span className={styles.eventDetailIcon}>◷</span>
                        {formatEventDate(event.event_date)}
                      </span>
                      <span className={styles.eventDetail}>
                        <span className={styles.eventDetailIcon}>📍</span>
                        {event.location}
                      </span>
                    </div>
                  </div>

                  <span className={styles.eventArrow} aria-hidden>
                    →
                  </span>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
