import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchPublicEvents } from '../../api/events';
import { HeroSection } from '../../components/public/HeroSection';
import { EventCard } from '../../components/public/EventCard';
import type { PublicEventListItem } from '../../types/event';
import styles from './HomePage.module.css';

export function HomePage() {
  const [events, setEvents] = useState<PublicEventListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchPublicEvents(3)
      .then(setEvents)
      .catch(() => setError('Не вдалося завантажити події'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <HeroSection />

      <section className={styles.mission}>
        <div className={styles.missionInner}>
          <div>
            <span className={styles.missionLabel}>Наша місія</span>
            <h2 className={styles.missionTitle}>Рух — частина студентського життя</h2>
          </div>
          <p className={styles.missionText}>
            Ми створюємо простір, де кожен студент НаУКМА може знайти свою активність —
            від благодійних марафонів до міжуніверситетських турнірів. Наша мета —
            популяризувати здоровий спосіб життя та зміцнювати спільноту через спорт.
          </p>
        </div>
      </section>

      <section id="latest-events" className={styles.section}>
        <div className={styles.sectionHeader}>
          <div>
            <h2 className={styles.sectionTitle}>Останні події</h2>
            <p className={styles.sectionSubtitle}>Активне життя організації</p>
          </div>
          <Link to="/events" className={styles.viewAll}>
            Усі події →
          </Link>
        </div>

        {loading && <p className={styles.loading}>Завантаження...</p>}
        {error && <p className={styles.error}>{error}</p>}
        {!loading && !error && events.length === 0 && (
          <p className={styles.empty}>Наразі немає опублікованих подій</p>
        )}
        {!loading && !error && events.length > 0 && (
          <div className={styles.grid}>
            {events.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
