import styles from './Badge.module.css';

interface BadgeProps {
  published: boolean;
}

export function Badge({ published }: BadgeProps) {
  return (
    <span className={`${styles.badge} ${published ? styles.published : styles.draft}`}>
      {published ? 'Опубліковано' : 'Чернетка'}
    </span>
  );
}
