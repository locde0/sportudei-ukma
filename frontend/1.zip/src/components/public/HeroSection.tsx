import { Link } from 'react-router-dom';
import styles from './HeroSection.module.css';

export function HeroSection() {
  return (
    <section className={styles.hero}>
      <div className={styles.inner}>
        <div>
          <span className={styles.eyebrow}>Спортудей · НаУКМА</span>
          <h1 className={styles.title}>
            <span className={styles.titleAccent}>Спорт</span> завжди!
          </h1>
          <p className={styles.subtitle}>
            Sportudei об'єднує студентів навколо фізичної активності: марафони,
            турніри, лекції та офлайн-події. Динаміка, драйв і молодіжна енергія спорту.
          </p>
          <div className={styles.actions}>
            <Link to="/events" className={styles.ctaPrimary}>
              Події
            </Link>
            <a href="#latest-events" className={styles.ctaSecondary}>
              Останні активності
            </a>
          </div>
        </div>

        <div className={styles.stats}>
          <div className={styles.statCard}>
            <div className={styles.statValue}>12+</div>
            <div className={styles.statLabel}>Подій щороку</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statValue}>500+</div>
            <div className={styles.statLabel}>Учасників</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statValue}>6</div>
            <div className={styles.statLabel}>Видів спорту</div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statValue}>10</div>
            <div className={styles.statLabel}>Років традиції</div>
          </div>
        </div>
      </div>
    </section>
  );
}
