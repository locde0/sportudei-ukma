import { useEffect, useState } from 'react';
import { fetchPublicEvents } from '../../api/events';
import { EventCard } from '../../components/public/EventCard';
import type { PublicEventListItem } from '../../types/event';
import styles from './EventsCatalog.module.css';

export function EventsCatalog() {
  const [events, setEvents] = useState<PublicEventListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchPublicEvents(100)
      .then(setEvents)
      .catch(() => setError('Не вдалося завантажити каталог подій'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1 className={styles.title}>Каталог подій</h1>
        <p className={styles.subtitle}>
          Марафони, турніри, лекції та інші активності Sportudei-UKMA
        </p>
      </header>

      {loading && <p className={styles.loading}>Завантаження...</p>}
      {error && <p className={styles.error}>{error}</p>}
      {!loading && !error && events.length === 0 && (
        <p className={styles.empty}>Наразі немає опублікованих подій</p>
      )}
      {!loading && !error && events.length > 0 && (
        <div className={styles.grid}>
          {events.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
}
